package com.github.teocci.testing.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.github.teocci.testing.ntp.AtomicTime;
import com.github.teocci.testing.ntp.AtomicTimeSingleton;
import com.github.teocci.testing.utils.LogHelper;

import org.apache.commons.net.ntp.TimeStamp;

/**
 * Created by teocci.
 *
 * @author teocci@yandex.com on 2019-Jul-08
 */
public class NTPAndroid extends AppCompatActivity
{
    private static String TAG = LogHelper.makeLogTag(NTPAndroid.class);

    private AtomicTime atomicTime;

    /**
     * Called when the activity is first created.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        atomicTime = AtomicTimeSingleton.getInstance();
        TimeStamp currentNtpTime = TimeStamp.getNtpTime(atomicTime.getTime());

        LogHelper.e(TAG, "Atomic time:\t" + currentNtpTime + " -> " + currentNtpTime.toDateString());
    }
}
